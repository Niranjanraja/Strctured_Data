import streamlit as st
from langchain.llms import OpenAI
from pathlib import Path
from langchain.callbacks.openai_info import OpenAICallbackHandler
from langchain.agents import *
from langchain.sql_database import SQLDatabase
import sqlite3
import pandas as pd
from langchain.agents import AgentExecutor
from langchain.agents import load_tools
from langchain.agents import initialize_agent
import openai
from dotenv import load_dotenv
from langchain.llms import AzureOpenAI
from langchain.chains.llm import LLMChain

#Defining sql db
db = SQLDatabase.from_uri("sqlite:///my_data.db")

#Ai configurations and imports
openai.api_type = "azure"
openai.api_base = "https://gptusecaselatentview.openai.azure.com/"
openai.api_version = "2023-03-15-preview"
openai.api_key = "4229ca7d85e245c89a8586a5af6130a5"
GPT_MODEL = "gpt-lv-usecase"

#Defining_llm
llm = AzureOpenAI(temperature=0, 
             engine=GPT_MODEL,
             openai_api_key = "4229ca7d85e245c89a8586a5af6130a5",
             openai_api_version = "2023-03-15-preview",
             verbose = True,
             )

#--Prompts
dialect = db.dialect
top_k = 10

SQL_PREFIX = """You are an agent designed to interact with a SQL database.
Given an input question, create a syntactically correct {dialect} query to run, then look at the results of the query and return the answer.
Unless the user specifies a specific number of examples they wish to obtain, always limit your query to at most {top_k} results.
You can order the results by a relevant column to return the most interesting examples in the database.
Never query for all the columns from a specific table, only ask for the relevant columns given the question.
You have access to tools for interacting with the database.
Only use the below tools. Only use the information returned by the below tools to construct your final answer.
You MUST double check your query before executing it. If you get an error while executing a query, rewrite the query and try again.
DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database.
If the question does not seem related to the database or the tools provided, just return "What are you talking about?" as the answer.
"""
SQL_SUFFIX = """Begin!
Question: {input}
Thought: I should look at the tables in the database to see what I can query.  Then I should query the schema of the most relevant tables.
{agent_scratchpad}"""
SQL_FUNCTIONS_SUFFIX = """I should look at the tables in the database to see what I can query.  Then I should query the schema of the most relevant tables."""

PREFIX = """Answer the following questions as best you can. You have access to the following tools:"""
FORMAT_INSTRUCTIONS = """Use the following format:
Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times untill the final answer to the input question is reached)
Thought: I now know the final answer
Final Answer: the final answer to the original input question"""
SUFFIX = """Begin!
Question: {input}
Thought:{agent_scratchpad}"""

INPUT_VARIABLES = ["input", "agent_scratchpad", "top_k", "dialect"]

query_sql_database_tool_description = (
    "Input to this tool is a detailed and correct SQL query, output is a "
    "result from the database. If the query is not correct, an error message "
    "will be returned. If an error is returned, rewrite the query, check the "
    "query, and try again. If you encounter an issue with Unknown column "
    "'xxxx' in 'field list', using schema_sql_db to query the correct table "
    "fields."
)
info_sql_database_tool_description = (
    "Input to this tool is a comma-separated list of tables, output is the "
    "schema and sample rows for those tables. "
    "Be sure that the tables actually exist by calling list_tables_sql_db "
    "first! Example Input: 'table1, table2, table3'"
)

#Tools
from langchain.tools.sql_database.tool import (
    InfoSQLDatabaseTool,
    ListSQLDatabaseTool,
    QuerySQLCheckerTool,
    QuerySQLDataBaseTool,
)

#Tools\
tools = [
            QuerySQLDataBaseTool(
                db=db, description=query_sql_database_tool_description
            ),
            InfoSQLDatabaseTool(
                db=db, description=info_sql_database_tool_description
            ),
            ListSQLDatabaseTool(db=db),
            QuerySQLCheckerTool(db=db, llm=llm),
        ]

tool_names = [tool.name for tool in tools]

#Prompt
prompt = ZeroShotAgent.create_prompt(
tools,
prefix=SQL_PREFIX,
suffix=SQL_SUFFIX,
format_instructions=FORMAT_INSTRUCTIONS,
input_variables=INPUT_VARIABLES,
)


#LLM
llm_chain = LLMChain(
llm=llm,
prompt=prompt,
callback_manager=None,
)


def main():

    load_dotenv()

    st.title("Query Your CSV 📈")

    st.sidebar.markdown("""
        <div class="expandable">
            <span class="expandable-header" style="font-weight: bold;">QSP - </span>
            <span class="expandable-content">Querying Structured Data</span>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Upload CSV File
    uploaded_csv = st.sidebar.file_uploader("Upload a CSV file", type=["csv"])

    # SQLite Database Connection
    conn = sqlite3.connect('my_data.db')
    c = conn.cursor()

    # Display uploaded data
    if uploaded_csv is not None:
        st.write("Uploaded CSV Data:")
        df = pd.read_csv(uploaded_csv)
        st.write(df)

        # Store uploaded data in SQLite table
        table_name = "your_table_name"  # Replace with your desired table name
        try:
            df.to_sql(table_name, conn, if_exists='replace', index=False)
            st.success("Data stored in the SQLite table successfully!")
        except Exception as e:
            st.error("An error occurred while storing data: {}".format(str(e)))

        conn.close()  # Close the database connection

    # SQL Agent Code
    llm = OpenAI(temperature=0, engine=GPT_MODEL, openai_api_key="4229ca7d85e245c89a8586a5af6130a5")

    # Initialize SQL Agent and tools
    tools = load_tools(tool_names)
    agent = ZeroShotAgent(llm_chain=llm_chain, allowed_tools=tool_names, **({}))
    initialize_agent(agent, db, tools)

    # Create AgentExecutor
    agentexecutor = AgentExecutor(agent=agent, tools=tools, callback_manager=None, verbose=True,
                                  max_iterations=10, max_execution_time=30, early_stopping_method='force',
                                  **({}))

    # Execute SQL Agent on User Input
    user_input = st.text_input("Ask a question:", "")
    if st.button("Get Answer"):
        # Execute the agent to answer user's question
        response = agentexecutor.execute(user_input)
        st.write("Agent Response:")
        st.write(response)

if __name__ == "__main__":
    main()
