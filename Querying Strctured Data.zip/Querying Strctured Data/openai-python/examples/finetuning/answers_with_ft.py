# This code example has moved. You can now find it in the [OpenAI Cookbook](https://github.com/openai/openai-cookbook)
# at [examples/fine-tuned_qa](https://github.com/openai/openai-cookbook/tree/main/examples/fine-tuned_qa)
