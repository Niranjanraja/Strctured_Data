import streamlit as st
import pandas as pd
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from langchain.agents.agent_types import AgentType
from langchain.agents import create_csv_agent
from dotenv import load_dotenv
import pandas as pd
import openai
import tempfile
import os

openai.api_type = "azure"
openai.api_base = "https://gptusecaselatentview.openai.azure.com/"
openai.api_version = "2023-03-15-preview"
openai.api_key = "4229ca7d85e245c89a8586a5af6130a5"
GPT_MODEL = "gpt-lv-usecase"

def main():

    load_dotenv()

    st.title("Query Your CSV 📈")

    st.sidebar.markdown("""
        <div class="expandable">
            <span class="expandable-header" style="font-weight: bold;">QSP - </span>
            <span class="expandable-content">Querying Structured Data</span>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    
    # Upload Excel file
    user_csv = st.sidebar.file_uploader("Upload your CSV File", type="CSV")

    if user_csv is not None:
        user_question = st.text_input("Question your CSV:")

        with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as temp_file:
            temp_file.write(user_csv.read())
        temp_path = temp_file.name

        #csv_data=user_csv.read()

        llm = OpenAI(temperature=0,engine=GPT_MODEL)
        agent = create_csv_agent(llm, temp_path, verbose=True)

        if user_question is not None and user_question != "":
            response = agent.run(user_question)

            st.write(response)

        os.unlink(temp_path)

    
   
        
    # Upload PDF file
    pdf_file = st.sidebar.file_uploader("Upload PDF File", type=["pdf"])

    if user_csv:
        st.sidebar.success("CSV file uploaded successfully.")
        # Process the uploaded Excel file if needed
        # data = pd.read_csv(user_csv)

    if pdf_file:    
        st.sidebar.success("PDF file uploaded successfully.")
        # Process the uploaded PDF file if needed
        # Example: text = extract_text_from_pdf(pdf_file)

if __name__ == "__main__":
    main()
